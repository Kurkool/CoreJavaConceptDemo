package myPack;


import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        //--- ex1
//        ArraysExercise ae = new ArraysExercise();
//        ae.arrProcedure();

        //--- ex2
        MethodsInJavaExercise methodInJava = new MethodsInJavaExercise();
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[5];

        System.out.println("Please input 5 int value:");
        for(int i = 0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        methodInJava.getOddValues(arr);

        //--- ex3
    }
}
