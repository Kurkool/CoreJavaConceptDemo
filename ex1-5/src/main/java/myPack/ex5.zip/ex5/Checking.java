package myPack;

public class Checking extends Account{
    public Checking(String accountType, Customer customer) {
        super(accountType, customer);
    }
}
