package myPack;

public class Savings extends Account{

    public Savings(String accountType, Customer customer) {
        super(accountType, customer);
    }
}
