package myPack;

public abstract class Account {
    public String accountType;
    private double balance;
    public Customer customer;

    public Account(String accountType, Customer customer) {
        this.accountType = accountType;
        this.customer = customer;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void deposit(double amount){
        System.out.println("Depositing... " + amount);
        double currentBalance = this.getBalance();
        double depositAmount = currentBalance + amount;
        this.setBalance(depositAmount);
        System.out.println("SUCCESSFUL TRANSACTION");
    }

    public void withdraw(double amount) throws Exception {
        System.out.println("Please wait while withdrawing amount:"+amount);
        double currentBalance = this.getBalance();
//        if(currentBalance < amount){
//            throw new Exception("TRANSACTION DENIED. Insufficient funds");
//        }else{
//            double withdrawAmount = currentBalance - amount;
//            this.setBalance(withdrawAmount);
//            System.out.println("SUCCESSFUL TRANSACTION");
//        }

        if(currentBalance < amount){
            System.out.println("TRANSACTION DENIED. Insufficient funds");
        }else{
            double withdrawAmount = currentBalance - amount;
            this.setBalance(withdrawAmount);
            System.out.println("SUCCESSFUL TRANSACTION");
        }
    }

    public void display(){
            System.out.println("Customer Account Name:" + this.customer.getFirstName());
            System.out.println(this.accountType + " Account Balance:" + this.getBalance());
    }


}
